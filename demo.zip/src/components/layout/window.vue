<template>
  <div class="biosen-window">
      <div class="biosen-window-title">
          <slot name="header">{{title}}</slot>
      </div>
      <div class="biosen-window-btn biosen-window-left fa fa-angle-left"></div>
      <div class="biosen-window-btn biosen-window-right fa fa-angle-right"></div>
      <div class="biosen-window-btn biosen-window-min fa fa-minus"></div>
      <div class="biosen-window-btn biosen-window-close fa fa-close"></div>
      <div class="biosen-window-container">
          <slot name="content"></slot>
      </div>
  </div>
</template>

<script>
export default {
  name: 'window',
  props:["title"]
}
</script>

<style scope>
.biosen-window{
    position:absolute;
    top:75px;
    left:0;
    right:0;
    margin:auto;
    width:calc(100% - 20px);
    height:calc(100% - 85px);
    background-color:rgb(48, 65, 86);;
    border-radius: 10px;
    z-index:1000;
}

.biosen-window > *{
    z-index:1005;
}

.biosen-window-title{
    color:#fff;
    position:absolute;
    top:0;
    left:0;
    right:0;
    margin:auto;
    padding:5px;
    width:200px;
}

.biosen-window-btn{
    background-color:#1f2d3d;
    height:17px;
    width:25px;
    line-height:17px;
    vertical-align: middle;
    border-radius:3px;
    color:#fff;
}

.biosen-window-left{
    position:absolute;
    top:7px;
    left:20px;
}

.biosen-window-right{
    position:absolute;
    top:7.5px;
    left:50px;
}

.biosen-window-close{
    position:absolute;
    top:7.5px;
    right:20px;
}

.biosen-window-min{
    position:absolute;
    top:7.5px;
    right:50px;
}

.biosen-window-container{
    position:relative;
    top:31px;
    left:0;
    right:0;
    height:calc(100% - 61px);
    width:calc(100% - 40px);
    margin:auto;
    background-color:#d2e8f5;
    border-radius: 5px;
    padding:10px;
}

.biosen-window-tabs > a{
    display:inline-block;
    text-decoration: none;
    color:#fff;
    font-size:14px;
    padding:3px 10px;
    position:relative;
    background:gray;
    border-radius: 5px;;
    margin:0 5px;
    top:-2px;
}

.biosen-window-tabs > a.router-link-exact-active{
    background: #1f2d3d;;
}

.biosen-window-content{
    position:relative;
    height:100%;
    width:100%;
}

.biosen-window-content > div{
    height:100%;
}
</style>