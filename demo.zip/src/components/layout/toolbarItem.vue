<template>
  <div class="biosen-toolbar-item" :style="{width:itemWidth + 'px'}" :class="classstr" @mouseenter="MouseIn" @mouseleave="MouseOut">
      <router-link :to="to">
        <img class="biosen-toolbar-item-icon" :src="iconUrl" :style="{width:itemWidth + 'px', height:itemWidth + 'px'}">
        <div class="biosen-toolbar-item-title">{{title}}</div>
      </router-link>
  </div>
</template>

<script>

export default {
  name: 'Toolbar',
  props:["to", "title", "iconUrl", "itemWidth"],
  data(){
      return {
          classstr:''
      }
  },
  computed:{
      width(){
          return this.classstr.indexOf("hover") > -1 ? 112:this.itemWidth
      }
  },
  methods:{
      MouseIn(){
          this.classstr = 'hover'
      },
      MouseOut(){
          this.classstr = ''
      }
  }
}
</script>

<style scope>
.biosen-toolbar-item {
    display:inline-block;
    height:75px;
    position:relative;
}

.biosen-toolbar-item-icon{
    width:60px;
    height:60px;
    position:absolute;
}

.biosen-toolbar.top .biosen-toolbar-item-icon{
    top:7.5px;
    left:0;
    right:0;
}

.biosen-toolbar.bottom .biosen-toolbar-item-icon{
    bottom:7.5px;
    left:0;
    right:0;
}

.biosen-toolbar-item-title{
    display:none;
    color:white;
    position:absolute;
    height:20px;
    line-height: 20px;
    vertical-align: middle;
    border-radius: 5px;;
    background-color: rgba(15, 15, 0, 0.45);
}

.biosen-toolbar.top .biosen-toolbar-item-title{
    top:120px;
    left:0;
    right:0;
}

.biosen-toolbar.bottom .biosen-toolbar-item-title{
    bottom:120px;
    left:0;
    right:0;
}

.biosen-toolbar-item:hover .biosen-toolbar-item-title{
    display:block !important;
}

.biosen-toolbar.top .biosen-toolbar-item .router-link-exact-active img{
    top:-2px;
}

.biosen-toolbar.bottom .biosen-toolbar-item .router-link-exact-active img{
    bottom:-2px;
}

</style>