<template>
  <div class="biosen-toolbar top" ref="toolbar" :style="{width:width+'px'}" @mousemove="mouseMoveHandler" @mouseleave="MouseOut">
      <ToolbarItem v-for="(item, index) in items" :key="index" :to="item.to" :title="item.title" :iconUrl="item.iconUrl" :itemWidth="item.width"></ToolbarItem>
  </div>
</template>

<script>
import ToolbarItem from './toolbarItem.vue'
export default {
  name: 'Toolbar',
  data(){
      return {
          width:200,
          items:[
              {title:'finder', to:"/manager", iconUrl:require('@/assets/finder.png'), width:60},
              {title:'finder', to:"/demo1", iconUrl:require('@/assets/finder.png'), width:60},
              {title:'finder', to:"/demo2", iconUrl:require('@/assets/finder.png'), width:60},
              {title:'finder', to:"/4", iconUrl:require('@/assets/finder.png'), width:60},
              {title:'finder', to:"/5", iconUrl:require('@/assets/finder.png'), width:60},
          ]
      }
  },
  components: {
      ToolbarItem
  },
  mounted(){
      var items = document.querySelectorAll(".biosen-toolbar-item")
      this.width = items.length * 60 + 200
      this.items.forEach((x, i)=>{
            var item = document.querySelector(".biosen-toolbar-item:nth-child(" + (i + 1) + ")")
            if(item.innerHTML.indexOf("router-link-active") > -1){
                x.width = 80
            } else {
                x.width = 60
            }
        })
  },
  methods:{
      MouseOut(){
          this.items.forEach((x, i)=>{
              var item = document.querySelector(".biosen-toolbar-item:nth-child(" + (i + 1) + ")")
              if(item.innerHTML.indexOf("router-link-active") > -1){
                  x.width = 80
              } else {
                  x.width = 60
              }
          })
          var item = document.querySelector(".biosen-toolbar-item .router-link-active")
      },
      mouseMoveHandler(e){
        this.items.forEach((x, i)=>{
            var item = document.querySelector(".biosen-toolbar-item:nth-child(" + (i + 1) + ")")
            if(item.innerHTML.indexOf("router-link-active") > -1){
                x.width = 80
            } else {
                x.width = 60
            }
        })
        var items = document.querySelectorAll(".biosen-toolbar-item")
        let index = -1
        for(let i=0; i<items.length; i++){
            if(items[i].classList.contains("hover")){
                index = i
                break
            }
        }
        if(index != -1){
            var item = document.querySelector(".biosen-toolbar-item:nth-child(" + (index + 1) + ")")
            if(item && item.getClientRects){
                var rect = item.getClientRects()
                let midx = (rect[0].left + rect[0].right)/2
                let offset = Math.abs(e.clientX-midx)
                let width = 112 * Math.sin((112-offset)*3.14159/224)
                this.items[index].width = width
                if(index < items.length-1){
                    this.items[index+1].width = 80 * Math.sin((112-offset)*3.14159/224)
                }
                if(index > 0){
                    this.items[index-1].width = 80 * Math.sin((112-offset)*3.14159/224)
                }
            }
            
        }
          
      }
  }
}
</script>

<style scope>
.biosen-toolbar {
    position: absolute;
    margin: 0 auto;
    height: 75px;
    border-radius: 10px;
    background-color: rgba(15, 15, 0, 0.45);
}

.biosen-toolbar * {
    z-index:1100;
}

.biosen-toolbar.top {
    top: 0;
    left: 0;
    right: 0;
}

.biosen-toolbar.bottom {
    bottom: 0;
    left: 0;
    right: 0;
}
</style>