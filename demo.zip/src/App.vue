<template>
  <div id="app">
    <div class="biosen-container">
      <img class="biosen-logo" :src="require('@/assets/finder.png')">
      <div class="biosen-name">X-imaging Biosen 软件系统</div>
      <div class="biosen-role">欢迎登录！系统管理员！</div>
      <div class="biosen-user"></div>
      <div class="biosen-topbar"></div>
      <div class="biosen-desktop">
        <router-view></router-view>
      </div>
      <Toolbar></Toolbar>
    </div>
  </div>
</template>

<script>
import Toolbar from '@/components/layout/toolbar'
export default {
  name: 'App',
  components: {
    Toolbar
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

.biosen-logo{
  position:absolute;
  top:0;
  left:0;
  height:75px;
  width:75px;
}

.biosen-name{
  background-color: rgba(15, 15, 0, 0.45);
  height:30px;
  line-height: 30px;
  vertical-align: middle;
  border-radius: 15px;
  padding:0px 10px;
  color:#fff;
  position:absolute;
  top:22.5px;
  left:110px;
}

.biosen-role{
  background-color: rgba(15, 15, 0, 0.45);
  height:30px;
  line-height: 30px;
  vertical-align: middle;
  border-radius: 15px;
  padding:0px 10px;
  color:#fff;
  position:absolute;
  top:22.5px;
  right:110px;
}

.biosen-user{
  height:60px;
  width:60px;
  border-radius: 30px;
  background:#fff;
  position:absolute;
  top:5px;
  right:5px;
}
</style>
