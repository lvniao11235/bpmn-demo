import Vue from "vue";
import VueRouter from "vue-router";
import Cookies from 'js-cookie'
Vue.use(VueRouter);

import Home from '@/views/home'
import Login from '@/views/login'
import Demo1 from '@/views/demo1'
import Demo2 from '@/views/demo2'
import Manager from '@/views/manager'
import UserManager from '@/views/userManager'
import RoleManager from '@/views/roleManager'
const router = new VueRouter({
    mode: "history",
    routes: [
        { path: "", redirect: "/home" },
        { path: "/login", component: Login },
        {
            path: "/home",
            component: Home,
            children: [{
                path: "/manager",
                component: Manager,
                children: [
                    { path: "", redirect: "user" },
                    { path: "user", component: UserManager },
                    { path: "role", component: RoleManager }
                ]
            }, {
                path: "/demo1",
                component: Demo1
            }, {
                path: "/demo2",
                component: Demo2
            }]
        },

    ]
})

router.beforeEach((to, from, next) => {
    if (to.path.toLowerCase() != "/login") {
        let user = JSON.parse(localStorage.getItem("currentUser"))
        if (user) {
            next()
        } else {
            next("/login")
        }
    } else {
        next()
    }

})
export default router