import Vue from "vue";
import VueRouter from "vue-router";
import Cookies from 'js-cookie'
Vue.use(VueRouter);

import Manager from '@/views/manager'
import UserManager from '@/views/userManager'
import RoleManager from '@/views/roleManager'
const router = new VueRouter({
    mode: "history",
    routes: [
        { path: "", redirect: "/manager" },
        {
            path: "/manager",
            component: Manager,
            children: [
                { path: "", redirect: "user" },
                { path: "user", component: UserManager },
                { path: "role", component: RoleManager }
            ]
        },
    ]
})

router.beforeEach((to, from, next) => {
    if (to.path.toLowerCase() != "/login") {
        let user = Cookies.get("currentUser")
        if (user) {
            next()
        } else {
            next("/login")
        }
    } else {
        next()
    }

})
export default router