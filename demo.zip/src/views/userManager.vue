<template>
    <div class="biosen-user-manager">
        <div class="biosen-group">
            <span>用户名：</span><el-input size="mini" placeholder="请输入内容"></el-input>
            <span>用户编号：</span><el-input size="mini" placeholder="请输入内容"></el-input>
            <span>用户状态：</span><el-select v-model="value" size="mini" placeholder="请选择"></el-select>
            <el-button size="mini">查询</el-button>
            <el-button size="mini">清空</el-button>
        </div>
        <div id="tableContainer" class="biosen-group" style="height:calc(100% - 78px);margin-top:10px;">
            <div class="table-header" style="width:calc(100% - 30px);margin:auto;text-align:left;">
                <span>用户列表：</span>
                <span style="float:right;"> 
                    <el-button size="mini">添加</el-button>
                    <el-button size="mini">编辑</el-button>
                    <el-button size="mini">删除</el-button>
                </span>
            </div>
            <!-- :style="{height:height+'px'}" -->
            <el-table 
                :data="tableData" stripe height="640"
                style="width:calc(100% - 30px);margin:15px auto 0;">
                <el-table-column
                    prop="number"
                    label="序号"
                    header-align="center"
                    align="center"
                    width="180">
                </el-table-column>
                <el-table-column
                    prop="name"
                    label="姓名"
                    header-align="center"
                    align="center"
                    width="180">
                </el-table-column>
                <el-table-column
                    prop="status"
                    header-align="center"
                    align="center"
                    label="状态">
                </el-table-column>
                <el-table-column
                    prop="unit"
                    header-align="center"
                    align="center"
                    label="部门">
                </el-table-column>
                <el-table-column
                    prop="note"
                    header-align="center"
                    align="center"
                    label="备注">
                </el-table-column>
                <el-table-column
                    header-align="center"
                    align="center"
                    label="操作">
                    <template >
                        <i class="el-icon-edit" style="margin-right:10px;"></i>
                        <i class="el-icon-delete"></i>
                    </template>
                </el-table-column>
            </el-table>
            <el-pagination style="margin-top:7px;"
                :page-sizes="[10, 15, 20]"
                :page-size="pagesize"
                layout="total, sizes, prev, pager, next, jumper"
                :total="total">
            </el-pagination>
        </div>
    </div>
</template>

<script>
export default {
  name: 'userManager',
  data(){
      return {
          value:0,
          total:10,
          pagesize:20,
          height:200,
          tableData: [{
                number: '001',
                name: '张三',
                status: '启用',
                unit: '实验一部',
                note: 'note'
            }, {
                number: '002',
                name: '李四',
                status: '启用',
                unit: '实验一部',
                note: 'note'
            }, {
                number: '001',
                name: '张三',
                status: '启用',
                unit: '实验一部',
                note: 'note'
            }, {
                number: '002',
                name: '李四',
                status: '启用',
                unit: '实验一部',
                note: 'note'
            }, {
                number: '001',
                name: '张三',
                status: '启用',
                unit: '实验一部',
                note: 'note'
            }, {
                number: '002',
                name: '李四',
                status: '启用',
                unit: '实验一部',
                note: 'note'
            }, {
                number: '001',
                name: '张三',
                status: '启用',
                unit: '实验一部',
                note: 'note'
            }, {
                number: '002',
                name: '李四',
                status: '启用',
                unit: '实验一部',
                note: 'note'
            }, {
                number: '001',
                name: '张三',
                status: '启用',
                unit: '实验一部',
                note: 'note'
            }, {
                number: '002',
                name: '李四',
                status: '启用',
                unit: '实验一部',
                note: 'note'
            }, {
                number: '001',
                name: '张三',
                status: '启用',
                unit: '实验一部',
                note: 'note'
            }, {
                number: '002',
                name: '李四',
                status: '启用',
                unit: '实验一部',
                note: 'note'
            }, {
                number: '001',
                name: '张三',
                status: '启用',
                unit: '实验一部',
                note: 'note'
            }, {
                number: '003',
                name: '张三',
                status: '启用',
                unit: '实验一部',
                note: 'note'
            }]
      }
  },
  mounted(){
    this.$nextTick(()=>{
        var container = document.querySelector("#tableContainer")
        this.height = container.clientHeight - 93
    })
  },
  methods:{
  }
}
</script>

<style scope>
.biosen-group{
    background-color:#b7d6ed;
    padding:10px;
    border-radius: 5px;
    position:relative;
}

.biosen-group .el-input{
    width:200px !important;
    margin-right:20px;
}

.biosen-group .el-button{
    background-color:#2f94d1;
    border-radius: 14px;;
    color:#fff;
    border:none;
    outline:none;
}

.biosen-user-manager table thead > tr, .biosen-user-manager table thead > tr > th{
    background-color:#2f94d1 !important;
    color:#fff;
}

.biosen-user-manager table tbody td{
    border-bottom:none !important;
}
</style>