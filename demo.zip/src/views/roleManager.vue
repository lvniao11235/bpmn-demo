<template>
    <div id="roleManager" class="biosen-role-manager">
        <div class="biosen-panel">
          <div class="biosen-panel-head">角色列表</div>
          <div class="biosen-panel-container">
              <el-table 
                :data="tableData" stripe height="250"
                style="width:100%;">
                <el-table-column
                    prop="roleNo"
                    label="角色编号"
                    header-align="center"
                    align="center"
                    width="180">
                </el-table-column>
                <el-table-column
                    prop="roleName"
                    label="角色名称"
                    header-align="center"
                    align="center"
                    width="180">
                </el-table-column>
                <el-table-column
                    prop="note"
                    header-align="center"
                    align="center"
                    label="备注">
                </el-table-column>
              </el-table>
          </div>
        </div>
        <div class="biosen-panel">
          <div class="biosen-panel-head">角色信息</div>
          <div class="biosen-panel-container" :style="{position:'relative', backgroundColor:'#fff', height:height+'px'}" >
            <el-row>
              <el-col :span="12">
                <div class="block" style="border-right:2px solid #646f76;position:relative;margin-top:10px;" :style="{height:(height-20)+'px'}">
                  <el-form id="form" :style="{top:top+'px'}" style="width:400px;margin:auto;position:relative;" size="mini" label-width="120px">
                    <el-form-item label="角色名称：" size="mini">
                      <el-input ></el-input>
                    </el-form-item>
                    <el-form-item label="用户编号：">
                      <el-input size="mini"></el-input>
                    </el-form-item>
                    <el-form-item label="账户状态：" style="text-align:left;">
                      <el-checkbox >启用</el-checkbox>
                      <el-checkbox >禁用</el-checkbox>
                    </el-form-item>
                    <el-form-item label="备注：">
                      <el-input size="mini"></el-input>
                    </el-form-item>
                  </el-form>
                </div>
              </el-col>
              <el-col :span="12">
                <div style="width:calc(100% - 40px);margin:auto;padding:20px;">
                  <div style="float:left;">权限列表：</div>
                  <div style="float:left;width:calc(100% - 150px);">
                    <el-tree
                      :data="data"
                      show-checkbox
                      node-key="id"
                      :default-expanded-keys="[2, 3]"
                      :default-checked-keys="[5]"
                      :props="defaultProps">
                    </el-tree>
                  </div>
                  <div style="float:right;">
                    <div><el-button size="mini">保存</el-button></div>
                    <div style="margin-top:10px;"><el-button size="mini">取消</el-button></div>
                  </div>
                </div>
              </el-col>
            </el-row>
          </div>
        </div>
    </div>
</template>

<script>
export default {
  name: 'roleManager',
  data(){
    return {
      height:200,
      top:50,
      tableData:[{
        roleNo:'1000', roleName:'系统管理员', note:'启用'
      }, {
        roleNo:'1001', roleName:'实验开发人员', note:'启用'
      }, {
        roleNo:'1002', roleName:'实验操作人员', note:'启用'
      }, {
        roleNo:'1003', roleName:'访客', note:'启用'
      }, ],
      data: [{
          id: 1,
          label: '一级 1',
          children: [{
            id: 4,
            label: '二级 1-1',
            children: [{
              id: 9,
              label: '三级 1-1-1'
            }, {
              id: 10,
              label: '三级 1-1-2'
            }]
          }]
        }, {
          id: 2,
          label: '一级 2',
          children: [{
            id: 5,
            label: '二级 2-1'
          }, {
            id: 6,
            label: '二级 2-2'
          }]
        }, {
          id: 3,
          label: '一级 3',
          children: [{
            id: 7,
            label: '二级 3-1'
          }, {
            id: 8,
            label: '二级 3-2'
          }]
        }],
    }
  },
  mounted(){
    this.$nextTick(()=>{
        var container = document.querySelector("#roleManager")
        this.height = container.clientHeight - 345
        var form = document.querySelector("#form")
        this.top = (this.height - form.clientHeight)/2
    })
  }
}
</script>

<style scope>
.biosen-panel{
  width:calc(100% - 30px);
  margin:10px auto 0;
}

.biosen-panel-head{
  background-color:#2f94d1;
  height:35px;
  line-height:35px;
  vertical-align: middle;
  color:#fff;
}

.biosen-role-manager .el-button{
    background-color:#2f94d1;
    border-radius: 14px;;
    color:#fff;
    border:none;
    outline:none;
    display:block;
}

.biosen-role-manager .el-tree-node__expand-icon{
  font:normal normal normal 14px/1 FontAwesome !important;
}

.biosen-role-manager .el-tree-node__expand-icon:before{
  content:"\f107" !important;
}

.biosen-role-manager .el-tree-node__expand-icon.expanded{
  transform: rotate(-90deg) !important;
}

</style>