<template>
    <div class="biosen-manager">
        <Window :title="'用户管理'">
            <div slot="header" class="biosen-window-tabs">
                <router-link to="/manager/user">
                    <div class="">用户管理</div>
                </router-link>
                <router-link to="/manager/role">
                    <div class="">角色管理</div>
                </router-link>
            </div>
            <div class="biosen-window-content" slot="content">
                <router-view></router-view>
            </div>
        </Window>
    </div>
</template>

<script>
import Window from '@/components/layout/window'
export default {
  name: 'userManager',
  components:{
      Window
  }
}
</script>

<style scope>


</style>