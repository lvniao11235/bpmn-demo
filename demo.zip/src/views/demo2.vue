<template>
<div class="biosen-container">
    demo2
</div>
</template>

<script>
export default {
  name: 'App',
}
</script>

<style>

</style>
