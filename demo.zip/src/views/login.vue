<template>
<div class="biosen-container">
    login
</div>
</template>

<script>
export default {
  name: 'App',
}
</script>

<style>

</style>
