<template>
<div class="biosen-container">
    demo1
</div>
</template>

<script>
export default {
  name: 'App',
}
</script>

<style>

</style>
